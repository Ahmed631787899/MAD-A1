import React, { useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { View, Text, Image, FlatList, TouchableOpacity, StyleSheet, TextInput, Button, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons'; // For icons in the bottom tab

// Sample Product Data
const products = [
  {
    id: '1',
    name: 'Wireless Earbuds',
    price: 49.99,
    image: 'https://via.placeholder.com/150',
    description: 'High-quality wireless earbuds with noise cancellation.',
  },
  {
    id: '2',
    name: 'Smartwatch',
    price: 129.99,
    image: 'https://via.placeholder.com/150',
    description: 'Fitness tracker with heart rate monitoring.',
  },
  {
    id: '3',
    name: 'Laptop Backpack',
    price: 39.99,
    image: 'https://via.placeholder.com/150',
    description: 'Durable and water-resistant laptop backpack.',
  },
  {
    id: '4',
    name: 'Bluetooth Speaker',
    price: 59.99,
    image: 'https://via.placeholder.com/150',
    description: 'Portable Bluetooth speaker with deep bass.',
  },
];

// Home Screen
function HomeScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <TextInput style={styles.searchBar} placeholder="Search products..." />
      <FlatList
        data={products}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity onPress={() => navigation.navigate('ProductDetails', { product: item })}>
            <View style={styles.productItem}>
              <Image source={{ uri: item.image }} style={styles.productImage} />
              <Text style={styles.productName}>{item.name}</Text>
              <Text style={styles.productPrice}>${item.price.toFixed(2)}</Text>
            </View>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

// Product Details Screen
function ProductDetailsScreen({ route, navigation }) {
  const { product } = route.params;
  const [cart, setCart] = useState([]);

  const addToCart = () => {
    setCart([...cart, product]);
    alert(`${product.name} added to cart!`);
  };

  return (
    <ScrollView style={styles.container}>
      <Image source={{ uri: product.image }} style={styles.detailsImage} />
      <Text style={styles.detailsName}>{product.name}</Text>
      <Text style={styles.detailsPrice}>${product.price.toFixed(2)}</Text>
      <Text style={styles.detailsDescription}>{product.description}</Text>
      <Button title="Add to Cart" onPress={addToCart} />
      <Button title="Go to Cart" onPress={() => navigation.navigate('Cart')} />
    </ScrollView>
  );
}

// Cart Screen
function CartScreen() {
  const [cart] = useState([
    { id: '1', name: 'Wireless Earbuds', price: 49.99 },
    { id: '2', name: 'Smartwatch', price: 129.99 },
  ]);

  const totalPrice = cart.reduce((sum, item) => sum + item.price, 0);

  return (
    <View style={styles.container}>
      <FlatList
        data={cart}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.cartItem}>
            <Text style={styles.cartItemName}>{item.name}</Text>
            <Text style={styles.cartItemPrice}>${item.price.toFixed(2)}</Text>
          </View>
        )}
      />
      <Text style={styles.total}>Total: ${totalPrice.toFixed(2)}</Text>
      <Button title="Checkout" onPress={() => alert('Proceed to Checkout')} />
    </View>
  );
}

// Order History Screen
function OrderHistoryScreen() {
  const orders = [
    { id: '1', name: 'Wireless Earbuds', status: 'Delivered' },
    { id: '2', name: 'Smartwatch', status: 'Shipped' },
  ];

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Order History</Text>
      <FlatList
        data={orders}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.orderItem}>
            <Text style={styles.orderItemName}>{item.name}</Text>
            <Text style={styles.orderItemStatus}>{item.status}</Text>
          </View>
        )}
      />
    </View>
  );
}

// Profile Screen
function ProfileScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Profile & Settings</Text>
      <TextInput style={styles.input} placeholder="Name" />
      <TextInput style={styles.input} placeholder="Email" />
      <Button title="Change Theme" onPress={() => alert('Theme Changed!')} />
    </View>
  );
}

// Bottom Tab Navigator
const Tab = createBottomTabNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={({ route }) => ({
          tabBarIcon: ({ focused, color, size }) => {
            let iconName;

            if (route.name === 'Home') {
              iconName = focused ? 'home' : 'home-outline';
            } else if (route.name === 'Cart') {
              iconName = focused ? 'cart' : 'cart-outline';
            } else if (route.name === 'OrderHistory') {
              iconName = focused ? 'list' : 'list-outline';
            } else if (route.name === 'Profile') {
              iconName = focused ? 'person' : 'person-outline';
            }

            return <Ionicons name={iconName} size={size} color={color} />;
          },
          tabBarActiveTintColor: 'blue',
          tabBarInactiveTintColor: 'gray',
        })}
      >
        <Tab.Screen name="Home" component={HomeScreen} />
        <Tab.Screen name="Cart" component={CartScreen} />
        <Tab.Screen name="OrderHistory" component={OrderHistoryScreen} />
        <Tab.Screen name="Profile" component={ProfileScreen} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}

// Styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#f5f5f5',
  },
  searchBar: {
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 8,
    marginBottom: 16,
    backgroundColor: '#fff',
  },
  productItem: {
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 8,
    marginBottom: 16,
    flexDirection: 'row',
    alignItems: 'center',
  },
  productImage: {
    width: 80,
    height: 80,
    borderRadius: 8,
    marginRight: 16,
  },
  productName: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  productPrice: {
    fontSize: 14,
    color: 'green',
  },
  detailsImage: {
    width: '100%',
    height: 200,
    borderRadius: 8,
    marginBottom: 16,
  },
  detailsName: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  detailsPrice: {
    fontSize: 20,
    color: 'green',
    marginBottom: 16,
  },
  detailsDescription: {
    fontSize: 16,
    marginBottom: 16,
  },
  cartItem: {
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 8,
    marginBottom: 16,
  },
  cartItemName: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  cartItemPrice: {
    fontSize: 14,
    color: 'green',
  },
  total: {
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 16,
    textAlign: 'right',
  },
  heading: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  input: {
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 8,
    marginBottom: 16,
    backgroundColor: '#fff',
  },
  orderItem: {
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 8,
    marginBottom: 16,
  },
  orderItemName: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  orderItemStatus: {
    fontSize: 14,
    color: 'gray',
  },
});