import React, { useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import { View, Text, TextInput, FlatList, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';

// Create the Stack and Tab Navigators
const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

// Dummy Data for Transactions
let initialTransactions = [
  { id: '1', type: 'expense', amount: 50, category: 'Food', date: '2023-10-01' },
  { id: '2', type: 'income', amount: 2000, category: 'Salary', date: '2023-10-05' },
  { id: '3', type: 'expense', amount: 100, category: 'Transport', date: '2023-10-10' },
];

// Dashboard Screen
const DashboardScreen = ({ budget, setBudget, transactions, handleAddExpense }) => {
  const totalIncome = transactions.filter((t) => t.type === 'income').reduce((sum, t) => sum + t.amount, 0);
  const totalExpenses = transactions.filter((t) => t.type === 'expense').reduce((sum, t) => sum + t.amount, 0);
  const balance = totalIncome - totalExpenses;
  const remainingBudget = budget - totalExpenses;

  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState('');
  const [date, setDate] = useState('');

  const handleSaveExpense = () => {
    if (!amount || !category || !date) {
      alert('Please fill all fields!');
      return;
    }

    const newExpense = {
      id: (Math.random() * 1000).toString(),
      type: 'expense',
      amount: parseFloat(amount),
      category,
      date,
    };
    handleAddExpense(newExpense);
    setAmount('');
    setCategory('');
    setDate('');
    alert('Expense Added!');
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.header}>Dashboard</Text>

      {/* Budget Card */}
      <View style={styles.card}>
        <Text style={styles.cardTitle}>Your Budget</Text>
        <Text style={styles.balanceText}>Remaining Budget: ${remainingBudget}</Text>
      </View>

      {/* Balance Card */}
      <View style={styles.card}>
        <Text style={styles.cardTitle}>Your Balance</Text>
        <Text style={styles.balanceText}>${balance}</Text>
      </View>

      {/* Add Expense */}
      <TextInput
        style={styles.input}
        placeholder="Amount"
        value={amount}
        onChangeText={setAmount}
        keyboardType="numeric"
      />
      <TextInput
        style={styles.input}
        placeholder="Category"
        value={category}
        onChangeText={setCategory}
      />
      <TextInput
        style={styles.input}
        placeholder="Date (YYYY-MM-DD)"
        value={date}
        onChangeText={setDate}
      />

      <TouchableOpacity style={styles.addButton} onPress={handleSaveExpense}>
        <Text style={styles.buttonText}>Add Expense</Text>
      </TouchableOpacity>

      {/* Recent Transactions */}
      <Text style={styles.subHeader}>Recent Transactions</Text>
      <FlatList
        data={transactions.slice(0, 5)}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.transactionCard}>
            <Text style={styles.transactionText}>{item.category}: ${item.amount} ({item.date})</Text>
          </View>
        )}
      />
    </ScrollView>
  );
};

// Transactions List Screen
const TransactionsListScreen = ({ transactions }) => {
  return (
    <ScrollView style={styles.container}>
      <Text style={styles.header}>Transactions</Text>
      <FlatList
        data={transactions}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.transactionCard}>
            <Text style={styles.transactionText}>
              {item.category}: ${item.amount} ({item.date})
            </Text>
          </View>
        )}
      />
    </ScrollView>
  );
};

// Budget Settings Screen
const BudgetSettingsScreen = ({ budget, setBudget }) => {
  const [monthlyLimit, setMonthlyLimit] = useState('');

  const handleSaveBudget = () => {
    if (!monthlyLimit) {
      alert('Please enter a budget!');
      return;
    }
    setBudget(parseFloat(monthlyLimit));
    alert(`Monthly Budget of $${monthlyLimit} Set!`);
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.header}>Budget Settings</Text>
      <TextInput
        style={styles.input}
        placeholder="Monthly Spending Limit"
        value={monthlyLimit}
        onChangeText={setMonthlyLimit}
        keyboardType="numeric"
      />
      <TouchableOpacity style={styles.addButton} onPress={handleSaveBudget}>
        <Text style={styles.buttonText}>Save Budget</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

// Profile Settings Screen
const ProfileSettingsScreen = ({ setTheme, theme }) => {
  const toggleTheme = () => {
    setTheme(theme === 'light' ? 'dark' : 'light');
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.header}>Profile & Settings</Text>
      <Text style={styles.subHeader}>Theme</Text>
      <TouchableOpacity style={styles.themeButton} onPress={toggleTheme}>
        <Text style={styles.buttonText}>
          {theme === 'light' ? 'Switch to Dark Theme' : 'Switch to Light Theme'}
        </Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

// Tab Navigator
const TabNavigator = ({ theme, setTheme }) => {
  const [budget, setBudget] = useState(0);
  const [transactions, setTransactions] = useState(initialTransactions);

  const handleAddExpense = (newExpense) => {
    setTransactions([...transactions, newExpense]);
  };

  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ color, size }) => {
          let iconName;

          if (route.name === 'Dashboard') {
            iconName = 'dashboard';
          } else if (route.name === 'Transactions') {
            iconName = 'list';
          } else if (route.name === 'Budget') {
            iconName = 'settings';
          } else if (route.name === 'Profile') {
            iconName = 'person';
          }

          size = size || 25;
          return <MaterialIcons name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: '#6200ee',
        tabBarInactiveTintColor: '#888',
        tabBarStyle: { backgroundColor: theme === 'light' ? '#fff' : '#1e1e1e' },
      })}
    >
      <Tab.Screen name="Dashboard">
        {() => (
          <DashboardScreen
            budget={budget}
            setBudget={setBudget}
            transactions={transactions}
            handleAddExpense={handleAddExpense}
          />
        )}
      </Tab.Screen>
      <Tab.Screen name="Transactions">
        {() => <TransactionsListScreen transactions={transactions} />}
      </Tab.Screen>
      <Tab.Screen name="Budget">
        {() => <BudgetSettingsScreen budget={budget} setBudget={setBudget} />}
      </Tab.Screen>
      <Tab.Screen name="Profile">
        {() => <ProfileSettingsScreen setTheme={setTheme} theme={theme} />}
      </Tab.Screen>
    </Tab.Navigator>
  );
};

// Main App
export default function App() {
  const [theme, setTheme] = useState('light');

  return (
    <NavigationContainer>
      <TabNavigator theme={theme} setTheme={setTheme} />
    </NavigationContainer>
  );
}

// Styles
const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  header: { fontSize: 26, fontWeight: 'bold', marginBottom: 20 },
  subHeader: { fontSize: 20, fontWeight: 'bold', marginBottom: 10 },
  card: { padding: 15, borderRadius: 10, marginBottom: 20, backgroundColor: '#f5f5f5' },
  cardTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 10 },
  balanceText: { fontSize: 24, fontWeight: 'bold' },
  transactionCard: { padding: 10, borderRadius: 10, marginBottom: 10, backgroundColor: '#e1e1e1' },
  transactionText: { fontSize: 16 },
  input: { padding: 10, borderRadius: 10, marginBottom: 10, backgroundColor: '#fff' },
  addButton: { backgroundColor: '#6200ee', padding: 15, borderRadius: 10, marginTop: 20 },
  buttonText: { color: '#fff', textAlign: 'center', fontWeight: 'bold' },
  themeButton: { padding: 15, borderRadius: 10, backgroundColor: '#6200ee', marginBottom: 10 },
});
